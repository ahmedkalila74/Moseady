package com.mosaedy.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.speech.*;
import java.util.*;

/** Opt-in foreground wake phrase listener. Android recognition services can stop or throttle it. */
public class WakeService extends Service implements RecognitionListener {
 private static final String CHANNEL="wake_listener";
 private SpeechRecognizer recognizer;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private boolean active=false;
 private boolean triggered=false;
 private final Runnable retry=this::startListening;
 public IBinder onBind(Intent i){return null;}
 @Override public void onCreate(){super.onCreate();NotificationManager nm=getSystemService(NotificationManager.class);
  nm.createNotificationChannel(new NotificationChannel(CHANNEL,"الاستماع لكلمة النداء",NotificationManager.IMPORTANCE_LOW));
  Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,101,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification note=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("مساعدي يستمع لكلمة النداء").setContentText("اضغط لفتح مساعدي؛ يمكنك إيقاف الاستماع من التطبيق").setOngoing(true).setContentIntent(pi).build();
  if(Build.VERSION.SDK_INT>=29)startForeground(101,note,ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);else startForeground(101,note);
  active=true;startListening();}
 private void startListening(){if(!active)return;if(!SpeechRecognizer.isRecognitionAvailable(this))return;
  try{if(recognizer!=null){recognizer.destroy();recognizer=null;}recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(this);
   Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-EG");i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
   recognizer.startListening(i);}catch(Exception e){schedule();}}
 private void schedule(){if(active&&!triggered){handler.removeCallbacks(retry);handler.postDelayed(retry,1200);}}
 private void check(Bundle b){if(b==null||triggered)return;ArrayList<String> words=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(words==null)return;
  String wake=getSharedPreferences("wake_settings",MODE_PRIVATE).getString("phrase","مساعدي").trim();if(wake.isEmpty())wake="مساعدي";
  for(String s:words){if(s.contains(wake)||s.contains("يا "+wake)){triggered=true;active=false;handler.removeCallbacks(retry);
   Intent open=new Intent(this,MainActivity.class);open.setAction("com.mosaedy.app.WAKE");open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
   // Background activity starts may be blocked by Android. Provide a high-priority notification fallback.
   NotificationManager nm=getSystemService(NotificationManager.class);PendingIntent pi=PendingIntent.getActivity(this,102,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   nm.createNotificationChannel(new NotificationChannel("wake_alert","استجابة مساعدي",NotificationManager.IMPORTANCE_HIGH));
   nm.notify(102,new Notification.Builder(this,"wake_alert").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("مساعدي جاهز يسمعك").setContentText("اضغط للتحدث").setContentIntent(pi).setAutoCancel(true).build());
   try{startActivity(open);}catch(Exception ignored){}stopSelf();return;}}}
 public void onReadyForSpeech(Bundle b){}public void onBeginningOfSpeech(){}public void onRmsChanged(float r){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){}public void onError(int e){schedule();}public void onResults(Bundle b){check(b);schedule();}public void onPartialResults(Bundle b){check(b);}public void onEvent(int a,Bundle b){}
 @Override public void onDestroy(){active=false;handler.removeCallbacks(retry);if(recognizer!=null){recognizer.cancel();recognizer.destroy();}super.onDestroy();}
}
