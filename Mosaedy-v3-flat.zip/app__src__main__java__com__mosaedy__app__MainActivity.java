package com.mosaedy.app;
import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.os.*;import android.speech.*;import android.speech.tts.TextToSpeech;import android.view.*;import android.widget.*;import org.json.*;import java.text.*;import java.util.*;import java.util.regex.*;
public class MainActivity extends Activity {
 LinearLayout root,items;EditText command,wake;TextToSpeech tts;Spinner voices;Calendar selected=Calendar.getInstance();boolean dateChosen=false;
 int pad=18;
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(24,55,99));if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);
 tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("ar"));});render();if("com.mosaedy.app.WAKE".equals(getIntent().getAction()))new Handler().postDelayed(this::listen,500);}
 TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(20,44,78));t.setPadding(6,12,6,12);return t;}
 Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
 void say(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"reply");}
 void render(){ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(pad,pad,pad,pad);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackgroundColor(Color.WHITE);scroll.addView(root);setContentView(scroll);
 root.addView(text("مساعدي",28));root.addView(text("قول اللي محتاجه، وأنا هسجل موعدك تلقائيًا",16));
 command=new EditText(this);command.setHint("مثال: فكرني بكرة الساعة ٨ أكلم أحمد");command.setMinLines(2);root.addView(command);
 root.addView(button("🎙 اتكلم مع مساعدي",this::listen));root.addView(button("إرسال",()->parse(command.getText().toString())));
 root.addView(text("مواعيدي",21));items=new LinearLayout(this);items.setOrientation(1);root.addView(items);refresh();
 root.addView(button("إضافة موعد يدويًا (اختياري)",this::chooseDate));
 root.addView(button("حفظ الموعد اليدوي",()->{if(!dateChosen){say("اختار التاريخ والوقت الأول");return;}String v=command.getText().toString().trim();if(v.isEmpty()){say("اكتب المهمة الأول");return;}save(v,selected.getTimeInMillis());}));
 root.addView(text("الإعدادات",19));root.addView(text("كلمة النداء",13));wake=new EditText(this);wake.setText(getSharedPreferences("wake_settings",MODE_PRIVATE).getString("phrase","مساعدي"));root.addView(wake);
 root.addView(button("حفظ كلمة النداء",()->{getSharedPreferences("wake_settings",MODE_PRIVATE).edit().putString("phrase",wake.getText().toString().trim()).apply();say("اتحفظت كلمة النداء");}));
 root.addView(button("تشغيل الاستماع لكلمة النداء",this::enableWake));root.addView(button("إيقاف الاستماع",()->{stopService(new Intent(this,WakeService.class));say("تم إيقاف الاستماع");}));
 root.addView(button("إعدادات الصوت",()->{try{startActivity(new Intent("com.android.settings.TTS_SETTINGS"));}catch(Exception e){say("إعدادات الصوت مش متاحة");}}));
 root.addView(text("الاستماع الاختياري يعتمد على محرك التعرف الصوتي للهاتف، وقد يتوقف بسبب قيود البطارية أو أندرويد. قد يتطلب فتح التطبيق الضغط على إشعار عند قفل الشاشة. لا يوجد ذكاء اصطناعي سحابي في هذه النسخة.",12));}
 void enableWake(){if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},11);say("اسمح للميكروفون ثم اضغط تشغيل الاستماع مرة تانية");return;}try{Intent i=new Intent(this,WakeService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);say("تم تشغيل الاستماع لكلمة النداء");}catch(Exception e){say("تعذر تشغيل الاستماع: "+e.getMessage());}}
 protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);if("com.mosaedy.app.WAKE".equals(i.getAction()))new Handler().postDelayed(this::listen,500);}
 void refresh(){items.removeAllViews();JSONArray a=ReminderStore.get(this);SimpleDateFormat f=new SimpleDateFormat("EEE d MMM yyyy - h:mm a",new Locale("ar"));for(int j=0;j<a.length();j++)try{JSONObject o=a.getJSONObject(j);items.addView(text("• "+o.getString("title")+"\n"+f.format(new Date(o.getLong("at"))),16));}catch(Exception ignored){}if(a.length()==0)items.addView(text("مفيش تذكيرات لسه",14));}
 void save(String s,long when){if(when<=System.currentTimeMillis()){say("الوقت لازم يكون في المستقبل");return;}ReminderStore.add(this,s,when);ReminderStore.restore(this);say("اتسجل التذكير");refresh();}
 void chooseDate(){Calendar now=Calendar.getInstance();DatePickerDialog d=new DatePickerDialog(this,(view,y,m,day)->{TimePickerDialog t=new TimePickerDialog(this,(v,h,min)->{selected=Calendar.getInstance();selected.set(y,m,day,h,min,0);selected.set(Calendar.MILLISECOND,0);dateChosen=true;say("اتحدد الموعد "+new SimpleDateFormat("d/M/yyyy h:mm a",new Locale("ar")).format(selected.getTime()));},now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),false);t.show();},now.get(Calendar.YEAR),now.get(Calendar.MONTH),now.get(Calendar.DAY_OF_MONTH));d.getDatePicker().setMinDate(System.currentTimeMillis()-86400000L);d.show();}
 void listen(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},11);return;}Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-EG");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"قول التذكير");try{startActivityForResult(i,7);}catch(Exception e){say("التعرف على الكلام غير متوفر على الموبايل");}}
 protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==7 && res==RESULT_OK && data!=null){ArrayList<String> a=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty()){command.setText(a.get(0));parse(a.get(0));}}}
 void parse(String raw){String s=raw.trim();if(s.isEmpty()){say("قول أو اكتب طلبك");return;}
 String n=normalize(s);
 if(n.contains("عندي ايه")||n.contains("مواعيدي")){say("عندك "+ReminderStore.get(this).length()+" تذكيرات محفوظة");return;}
 Calendar c=Calendar.getInstance();long now=System.currentTimeMillis();boolean hasDay=false,hasTime=false;
 Matcher relative=Pattern.compile("(?:بعد|كمان)\\s+(\\d+|نص|ربع)\\s*(دقايق|دقيقه|دقائق|ساعه|ساعات|يوم|ايام)").matcher(n);
 if(relative.find()){String v=relative.group(1);double num=v.equals("نص")?0.5:v.equals("ربع")?0.25:Double.parseDouble(v);String unit=relative.group(2);long ms=unit.startsWith("د")?60000L:unit.startsWith("س")?3600000L:86400000L;save(cleanTitle(s),now+(long)(num*ms));return;}
 if(n.contains("بعد بكره")||n.contains("بعد بكرة")){c.add(Calendar.DATE,2);hasDay=true;}
 else if(n.contains("بكره")||n.contains("بكرة")||n.contains("غدا")){c.add(Calendar.DATE,1);hasDay=true;}
 else if(n.contains("النهارده")||n.contains("اليوم")){hasDay=true;}
 Matcher date=Pattern.compile("(?:يوم|تاريخ)\\s*(\\d{1,2})[/-](\\d{1,2})(?:[/-](\\d{4}))?").matcher(n);
 if(date.find()){int day=Integer.parseInt(date.group(1)),month=Integer.parseInt(date.group(2));int year=date.group(3)==null?c.get(Calendar.YEAR):Integer.parseInt(date.group(3));if(day<1||day>31||month<1||month>12){say("التاريخ مش صحيح");return;}c.set(year,month-1,day);hasDay=true;}
 Matcher time=Pattern.compile("(?:الساعه|ساعه|الساعة|عند)\\s*(\\d{1,2})(?:[:٫](\\d{1,2}))?").matcher(n);
 if(time.find()){int hour=Integer.parseInt(time.group(1)),minute=time.group(2)==null?0:Integer.parseInt(time.group(2));if(hour>23||minute>59){say("الساعة مش صحيحة");return;}
 boolean pm=n.contains("بالليل")||n.contains("المساء")||n.contains("مساء")||n.contains("العصر")||n.contains("المغرب");boolean am=n.contains("الصبح")||n.contains("صباح")||n.contains("الفجر");
 if(hour<=12){if(pm&&hour<12)hour+=12;if(am&&hour==12)hour=0;}
 c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,minute);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);hasTime=true;
 }
 if(!hasTime){say("فهمت المهمة، بس الساعة كام؟ اكتب الموعد أو قوله بالصوت");return;}
 if(!hasDay && c.getTimeInMillis()<=now)c.add(Calendar.DATE,1);
 if(hasDay && c.getTimeInMillis()<=now){say("الموعد اللي قلته فات. حدد وقت جاي");return;}
 save(cleanTitle(s),c.getTimeInMillis());
 }
 String normalize(String s){String n=s.replace('٠','0').replace('١','1').replace('٢','2').replace('٣','3').replace('٤','4').replace('٥','5').replace('٦','6').replace('٧','7').replace('٨','8').replace('٩','9');n=n.replace("خمسة","5").replace("خمس","5").replace("عشرة","10").replace("عشر","10").replace("تلاتة","3").replace("ثلاثة","3").replace("اتنين","2").replace("اثنين","2").replace("واحد","1").replace("سبعة","7").replace("سبع","7").replace("تمانية","8").replace("ثمانية","8").replace("تسعة","9").replace("تسع","9").replace("ستة","6").replace("ست","6").replace("اربعة","4").replace("أربعة","4");return n;}
 String cleanTitle(String s){return s.replaceFirst("^(فكرني|ذكرني|افتكرني|نبهني)\\s*","").trim();}
 protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
